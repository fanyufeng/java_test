public interface testInterface{
	public void test();
}
