public class testImpl2 implements testInterface{
	public void test(){
		System.out.println("testImpl2");
	}


}
