public class testImpl1 implements testInterface{
	public void test(){
		System.out.println("testImpl1");
	}

}
