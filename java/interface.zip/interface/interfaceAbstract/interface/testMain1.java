public class testMain1{
	public static void main(String[] args){
		testInterface ctr=new testImpl1();
		ctr.test();
	}
}
