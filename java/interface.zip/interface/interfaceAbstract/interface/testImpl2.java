public class testImpl2 extends testInterface{
	public void test(){
		System.out.println("testImpl2");
	}


}
