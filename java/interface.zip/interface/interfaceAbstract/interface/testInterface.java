public abstract class testInterface{
	public abstract void test();
	public void test1(){}
}
