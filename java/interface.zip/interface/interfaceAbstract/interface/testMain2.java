public class testMain2{
	public static void main(String[] args){
		testInterface ctr=new testImpl2();
		ctr.test();
	}
}
