public class testImpl1 extends testInterface{
	public void test(){
		System.out.println("testImpl1");
	}

}
